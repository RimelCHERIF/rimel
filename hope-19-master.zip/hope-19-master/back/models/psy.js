const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PsySchema = new Schema({
  lat: Number,
  lng: Number,
  name: String,
  profession: String,
  address: String,
  link: String
});

const Psy = mongoose.model('Psy', PsySchema, 'psys');

module.exports = Psy;
