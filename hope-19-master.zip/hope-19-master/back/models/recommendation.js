const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const RecommendationSchema = new Schema({
  imagePath: String,
  type: String,
  name: String,
  url: String
});

const Recommendation = mongoose.model('Recommendation', RecommendationSchema, 'recommendations');

module.exports = Recommendation;