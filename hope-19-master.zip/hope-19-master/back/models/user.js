const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const bcrypt = require('bcrypt');
const SALT_ROUNDS = 10;

const UserSchema = new Schema({
  firstName: String,
  lastName: String,
  age: Number,
  email: String,
  password: String
});

UserSchema.pre('save', function (next) {
  const user = this;
  // hash the password
  if (user.isModified('password')) {
    bcrypt.hash(user.password, SALT_ROUNDS, (err, encrypted) => {
      if (err) return next(err);
      user.password = encrypted;
      console.log(user.password)
      if (user.isModified('age')) {
        const age = parseInt(user.age);
        if (age === NaN)
          return next(new Error('user age is not an integer'));
        else
          user.age = age;
      }
      return next();
    });
  }


});

UserSchema.methods.verifyPassword = function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
}

const User = mongoose.model('User', UserSchema, 'users');

module.exports = User;