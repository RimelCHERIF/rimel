const express = require('express');
const router = express.Router();
const User = require('../models/user');


router.post('/', async (req, res) => {
  try {
    const { firstName, lastName, age, email } = await User.create(req.body);
    res.status(201).send({ firstName, lastName, age, email });
  } catch (err) {
    console.log(err)
    res.status(500).send({ err: 'user age is not an integer' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const user = await User.findOne({ email: req.body.email });
    console.log(user);
    const { firstName, lastName, age, email } = user;
    if (await user.verifyPassword(req.body.password))
      res.send({ firstName, lastName, age, email })
    else
      res.status(500).send({ err: 'passwords doesn\'t match' });
  } catch (err) {
    console.log(err);
    res.status(500).send({ err: 'cannot find user' });
  }
});

module.exports = router;
