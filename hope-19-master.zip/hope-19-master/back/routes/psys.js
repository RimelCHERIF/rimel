const express = require('express');
const router = express.Router({ mergeParams: true });
const Psy = require('../models/psy');

router.get('/closest', async (req, res) => {
  const { lat, lng, count } = req.query;
  try {
    return res.send((await Psy.find({}))
      .map(x => ({
        x,
        dist: calculateDistance(parseFloat(lat), parseFloat(lng), x.lat, x.lng)
      }))
      .sort((a, b) => a.dist - b.dist)
      .map(x => x.x)
      .slice(0, parseInt(count)));
  } catch (err) {
    console.log(err);
    res.status(404).send({ err: "didn't find any Psys" })
  }
})

router.get('/:id', async (req, res) => {
  try {
    res.send(await Psy.find({ _id: req.params.id }));
  } catch (err) {
    console.log(err);
    res.status(404).send({ err: "didn't find any Psys" })
  }
})

router.get('/', async (req, res) => {
  console.log('here')
  try {
    res.send(await Psy.find({}));
  } catch (err) {
    console.log(err);
    res.status(404).send({ err: "didn't find any Psys" })
  }
})

module.exports = router;

function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // metres
  const φ1 = lat1 * Math.PI / 180; // φ, λ in radians
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) *
    Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return d;
}
