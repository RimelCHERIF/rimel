const express = require('express');
const router = express.Router();
const Recommendation = require('../models/recommendation');

router.get('/', async function (req, res) {
  try {
    const allRecommendations = await Recommendation.find({});
    res.send(allRecommendations)
  } catch (err) {
    res.status(500).send({ err: 'Error fetching recommendations' })
  }
});

router.get('/:type', async function (req, res) {
  try {
    const type = req.params.type;
    const recommendations = await Recommendation.find({ type });
    res.send(recommendations)
  } catch (err) {
    res.status(500).send({ err: 'Error fetching recommendations' })
  }
});

router.get('/psys', (req, res, next) => {
  return next()
})


module.exports = router;