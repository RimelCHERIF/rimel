const express = require('express');
const logger = require('morgan');
const mongoose = require('mongoose');
const path = require('path');
const cors = require('cors');


const usersRouter = require('./routes/users');
const psysRouter = require('./routes/psys');
const recommendationRouter = require('./routes/recommendation');

// connect to mongodb database
try {
  mongoose.connect('mongodb://localhost/hope-19', { useNewUrlParser: true, useUnifiedTopology: true });
  console.log('connected to database');
} catch (err) {
  console.log('ERROR : database connection failed', err);
}

const app = express();


app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use('/static', express.static(path.join(__dirname, 'static')));
app.use(cors())


app.use('/users', usersRouter);
app.use('/recommendations/', recommendationRouter);
app.use('/psys', psysRouter);

module.exports = app;
