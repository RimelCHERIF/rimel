# Psy-Bot
A virtual Waiting room for people who have doubts about mental illnesses induced by the COVID-19 pandemic. Built using the MEAN stack and Ionic.
  
## Table of contents
- [Psy-Bot](#psy-bot)
  * [Table of contents](#table-of-contents)
  * [Technical Stack](#technical-stack)
  * [System Modules](#system-modules)
    + [Backend](#backend)
      - [Resources](#resources)
    + [AI Module](#ai-module)
    + [Front-end](#front-end)


## Technical Stack
The figure below shows an overview of the technical stack and architecture of the solution.

<center> <img src="architecture.png"> </center>

The solution is composed of 3 main modules:
- Back-end : The application management system module. It's a RESTful application written in [Node.JS](https://node.org/) and the [Express](https://expressjs.com) framework. We used as a Database [MongoDB](https://mongodb.com) for its high compatibility with Node.JS.
- AI Module: An AI-based backend module that specializes in text processing, it's written in Python using machine/deep learning libraries and exposes a RESTful API using the micro-framework [Flask](https://flask.palletsprojects.com/en/1.1.x/).
- Front-end: A smartphone application written in [Ionic](https://ionicframework.com/) Framework with the [Angular](https://angular.io/) integration. It interacts with both the Back-end and the AI module via HTTP.



## System Modules

### Backend
The Backend serves as the user management server as well as an interface for the database, fetching the different Recommendations (books, communities, psychologists). It uses [mongoose](https://mongoosejs.com) as an Object Management tool for mongoDB and [Bcrypt](https://www.npmjs.com/package/bcrypt) library to hash passwords.

#### Resources
- `POST /users` : Save a user

  - Input:
  ```javascript
  {
    firstName: String,
    lastName: String,
    age: Number,
    email: String,
    password: String
  }
  ```
  - Output:
    - `201 Created` : Query successful
      ```javascript
      {
        firstName: String,
        lastName: String,
        age: Number,
        email: String
      }
      ```
    - `500 Internal Server Error`: Query failed
      ```javascript
      {
        err: String // error message
      }
      ```


- `POST /users/login`: User login
  - Input:
    ```javascript
    {
      email: String,
      password: String
    }
    ```
  - Output:
    - `200 OK` : Query successful
      ```javascript
      {
        firstName: String,
        lastName: String,
        age: Number,
        email: String
      }
      ```
    - `500 Internal Server Error`: Query failed
      ```javascript
      {
        err: String // error message
      }
      ```

- `POST /users` : Save a user

  - Input:
  ```javascript
  {
    firstName: String,
    lastName: String,
    age: Number,
    email: String,
    password: String
  }
  ```
  - Output:
    - `201 Created` : Query successful
      ```javascript
      {
        firstName: String,
        lastName: String,
        age: Number,
        email: String
      }
      ```
    - `500 Internal Server Error`: Query failed
      ```javascript
      {
        err: String // error message
      }
      ```


- `POST /psys/closest`: get closest psychiatrists
  - Input:
    ```javascript
    {
      lat: Number,
      lng: Number,
      count: Number, // number of psychiatrists

    }
    ```
  - Output:
    - `200 OK` : Query successful
      ```javascript
      [
        {
          firstName: String,
          lastName: String,
          age: Number,
          email: String
        },
        ...
      ]
      ```
    - `500 Internal Server Error`: Query failed
      ```javascript
      {
        err: String // error message
      }
      ```

- `GET /psys/:id`: get a psychiatrist with id
  - Input:
    ```javascript
      id: Number
    ```
  - Output:
    - `200 OK` : Query successful
      ```javascript
      [
        {
          lat: Number,
          lng: Number,
          name: String,
          profession: String,
          address: String,
          link: String
        }
      ]
      ```
    - `500 Internal Server Error`: Query failed
      ```javascript
      {
        err: String // error message
      }
      ```

- `GET /psys/`: get all psychiatrists
  - Input: No input
  - Output:
    - `200 OK` : Query successful
      ```javascript
      [
        {
          firstName: String,
          lastName: String,
          age: Number,
          email: String
        },
        ...
      ]
      ```
    - `500 Internal Server Error`: Query failed
      ```javascript
      {
        err: String // error message
      }
      ```

- `GET /recommendation/`: get all recommendations
  - Input: No input
  - Output:
    - `200 OK` : Query successful
      ```javascript
      [
        {
          imagePath: String,
          type: String,
          name: String,
          url: String
        },
        ...
      ]
      ```
    - `500 Internal Server Error`: Query failed
      ```javascript
      {
        err: String // error message
      }
      ```

- `GET /recommendation/:type`: get recommendations by type
  - Input:
  ```javascript
      type: String
    ```
  - Output:
    - `200 OK` : Query successful
      ```javascript
      [
        {
          imagePath: String,
          type: String,
          name: String,
          url: String
        },
        ...
      ]
      ```
    - `500 Internal Server Error`: Query failed
      ```javascript
      {
        err: String // error message
      }
      ```

### AI Module
This module features two main components: 
- Score calculation component: It uses a deep learning model (Word2Vec) provided by the [gensim](https://radimrehurek.com/gensim/) library trained on a big dataset of words to calulate the similarity between the user input and a set of reference answers. This component will output a score that ranges from 1 to 4.
- Conversation component: It uses Natural Language Understanding and text mining tools to guide the flow of the conversation and make it as human-like as possible. These tools are provided via the [NLTK](https://www.nltk.org/) (Natural Language Tool Kit) Python Library.

### Front-end

This is where we implemented our user interface in order to let him take advantange of all the services that the backend and the AI modules offers. To do so, we used Ionic Framework with the Angular integration, this framework streamlines building cross platform mobile applications (Android and iOS) all while using the common Web technologies.

Here goes some of our UIs.
- Login and Signup
<center> <img src="Home Screen.jpg" width="30%"> </center>
<center><img src="SignUp.png" width="30%"> </center>
<center> <img src="SignIn.png" width="30%"> </center>


- Chatbot
<center> <img src="chatbot.png" width="30%"> </center>
<center> <img src="chatbot2.png" width="30%"> </center>


- Recommendation
<center> <img src="recommendation1.png" width="30%"></center>
<center> <img src="recommendation2.png" width="30%"></center>
