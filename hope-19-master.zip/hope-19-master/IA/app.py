import re
import nltk
nltk.download('wordnet')
from nltk.corpus import wordnet
nltk.download('stopwords')
from nltk.corpus import stopwords
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk import  pos_tag
from nltk.stem import PorterStemmer
from nltk.corpus import wordnet as wn
from collections import defaultdict


import gensim.downloader as api
wv = api.load('word2vec-google-news-300')

#Preprocessing the data 
def string_preprocess(message)  : 
    #remove hashtags and accounts from tweets
    message.replace(r'@.*?(?=\s|$)'," ")
    message.replace(r'#.*?(?=\s|$)'," ")
    message.replace('|||', ' ')
  
    #convert to lower case
    message.lower()
    #remove hyperlinks
    #remove punctuations
    message.replace('[^\w\s]'," ")
    #remove special characters
    message.replace("\W"," ")
    #remove digits
    message.replace("\d+"," ")
    #remove under scores
    message.replace("_"," ")
    message = message.strip()


    tag_map = defaultdict(lambda : wn.NOUN)
    tag_map['J'] = wn.ADJ
    tag_map['V'] = wn.VERB
    tag_map['R'] = wn.ADV
  
    porter=PorterStemmer()
    wordnet_lemmatizer = WordNetLemmatizer()
    token_words=word_tokenize(message)
    stem_sentence=[]
    for word, tag in pos_tag(token_words) :
    
        lemma = wordnet_lemmatizer.lemmatize(word,  tag_map[tag[0]])
        word = porter.stem(lemma)
        stem_sentence.append(word)
        stem_sentence.append(" ")
    return "".join(stem_sentence)


scores ={"Point1":1,"Point2":2,"Point3":3,"Point4":4} 
intent =["Point1","Point2","Point3","Point4"]


possible_responses=["A little of the time","Some of the time","Good part of the time","Most of the time "]


def calculate_score(message_from_user,ascendant):
    
    user_input = message_from_user.lower()
    input_preprocessed = string_preprocess(user_input)
    matched_intent = "Point1"#Default value if the intent doesnt match
    distance = wv.wmdistance(input_preprocessed, possible_responses[0])
    for i in range(1,4):
        new_distance = wv.wmdistance(input_preprocessed, possible_responses[i])
        if new_distance < distance:
            distance = new_distance
            matched_intent = intent[i]
    if ascendant == "False": 
        return(4-scores[matched_intent])
    return scores[matched_intent]


def add_score(message,ascendant):
    score = calculate_score(message,ascendant)
    result = {'score':score}
    return result


from flask import Flask, request, jsonify
from flask_cors import CORS
app = Flask(__name__)
CORS(app)
@app.route("/api/<string:message>/<string:ascendant>/",methods=['GET'])
def send_score(message,ascendant):
    if request.method == 'GET':
        result = add_score(message,ascendant)
        return jsonify(result)
if __name__ == '__main__':
    app.run(host = 'localhost', port = 9190,debug=False)