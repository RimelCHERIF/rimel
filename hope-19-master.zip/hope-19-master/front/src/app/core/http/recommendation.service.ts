import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RecommendationService {
  url = "http://localhost:3000"

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  constructor(private http: HttpClient) { }

  getAllPsy(): Observable<any[]> {
    return this.http.get<any[]>(this.url + '/psys', this.httpOptions)
  }

  getAllBooks(): Observable<any[]> {
    return this.http.get<any[]>(this.url + '/recommendations/book', this.httpOptions)
  }

  getAllCommunity(): Observable<any[]> {
    return this.http.get<any[]>(this.url + '/recommendations/group', this.httpOptions)
  }

  getAllSports(): Observable<any[]> {
    return this.http.get<any[]>(this.url + '/recommendations/sport', this.httpOptions)
  }

}
