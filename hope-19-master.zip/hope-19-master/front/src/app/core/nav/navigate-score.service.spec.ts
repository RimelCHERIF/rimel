import { TestBed } from '@angular/core/testing';

import { NavigateScoreService } from './navigate-score.service';

describe('NavigateScoreService', () => {
  let service: NavigateScoreService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NavigateScoreService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
