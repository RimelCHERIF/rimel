import { Component, OnInit } from '@angular/core';
import { Recommendation } from 'src/app/models/recommendation';
import { RecommendationService } from 'src/app/core/http/recommendation.service';
import { NavigateScoreService } from 'src/app/core/nav/navigate-score.service';

@Component({
  selector: 'app-recommendation',
  templateUrl: './recommendation.component.html',
  styleUrls: ['./recommendation.component.scss'],
})
export class RecommendationComponent implements OnInit {

  score = 50;
  level = 0;
  recommendationText = ""
  recommendations: Array<any> = [];

  constructor(private recommendationService: RecommendationService, private navigateScoreService: NavigateScoreService) {
  }

  ngOnInit() {
    if (this.navigateScoreService.score)
      this.score = this.navigateScoreService.score;
    console.log(this.score)
    if (this.score < 48) {
      this.level = 1
      this.editRecommendationText(1)
      this.recommendSport()
      this.recommendBook()
    } else {
      this.level = 2
      this.editRecommendationText(2)
      this.recommendPsy()
      this.recommendCommunity()
    }
  }

  recommendPsy() {
    this.recommendationService.getAllPsy().subscribe(res => {
      this.recommendations.push(...res)
    })
  }

  recommendBook() {
    this.recommendationService.getAllBooks().subscribe(res => {
      this.recommendations.push(...res)
    })
  }

  recommendSport() {
    this.recommendationService.getAllSports().subscribe(res => {
      this.recommendations.push(...res)
    })
  }

  recommendCommunity() {
    this.recommendationService.getAllCommunity().subscribe(res => {
      this.recommendations.push(...res)
    })
  }

  editRecommendationText(level: number) {
    if (level == 1) {
      this.recommendationText = "We recommend that you do more activities to reduce stress, like reading or excercising: Please find here after some books and some gyms that might interrest you 😊."
    } else[
      this.recommendationText = "We think that it would be better if you talk to a spetialaised doctor or to have a psychotherapy, Please find here after some usefull adresses 😊."
    ]



  }

}
