import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Conversation } from '../../shared/survey';
import { MenuController } from '@ionic/angular';
import { Router } from '@angular/router';
import { NavigateScoreService } from 'src/app/core/nav/navigate-score.service';
import { ScoringService } from 'src/app/core/http/scoring.service';


interface Message {
  text: string;
  timeStamp: Date;
  type: 'incoming' | 'outgoing';
  messageType: 'question' | 'response'
}

@Component({
  selector: 'app-chat',
  templateUrl: './chat.page.html',
  styleUrls: ['./chat.page.scss'],
})
export class ChatPage implements OnInit {

  score: number = 0;
  messages: Array<Message> = [];
  message: string = '';
  response: String;
  theme = 0;
  questionList = [0, 1, 2, 3];
  qNumber = -1

  constructor(private http: HttpClient, private menuCtrl: MenuController,
    private router: Router, private navigateScoreService: NavigateScoreService,
    private scoringService: ScoringService) { }

  async ngOnInit() {
    this.loadGreeting(0)
    this.sendMessage()

    await this.menuCtrl.enable(true);

  }


  sendMessage() {
    if (this.message !== '') {
      const outMessage: Message = {
        text: this.message,
        timeStamp: new Date(),
        type: 'incoming',
        messageType: 'question'
      };
      this.messages.push(outMessage);
      this.message = '';
    }
  }

  sendResponse() {
    if (this.message !== '') {
      const outMessage: Message = {
        text: this.message,
        timeStamp: new Date(),
        type: 'outgoing',
        messageType: 'response'
      };
      this.getResponseScore(this.qNumber, this.message)
      this.messages.push(outMessage);
      this.message = '';
      if (this.messages.length == 2 && Conversation.REFUSE.includes(outMessage.text)) {
        this.loadBye(1);
        this.sendMessage()
      } else {
        if (this.questionList.length == 4) {
          this.loadQuestion(true)
          this.sendMessage()
        } else if (this.questionList.length > 0) {
          this.loadQuestion(false)
          this.sendMessage()
        } else if (this.questionList.length == 0) {
          if (this.theme == 4) {
            this.loadBye(0);
            this.sendMessage()
            this.navigateToRecommendation()
          } else {
            this.theme += 1;
            this.questionList = [0, 1, 2, 3];
            this.loadQuestion(true)
            this.sendMessage()
          }
        }
      }
    }
  }

  getCssClasses(messageType) {
    return {
      incoming: messageType === 'incoming',
      outgoing: messageType === 'outgoing',
    };
  }

  getResponseScore(q, r) {
    if (q >= 0) {
      this.scoringService.get_score(r, String(Conversation.QUESTIONS[q].asc)).subscribe(res => {
        this.score += res.score
      })
    }

  }

  navigateToRecommendation() {
    //this.router.navigateByUrl('/recommendation');
    this.navigateScoreService.score = this.score
    setTimeout(() => {
      this.router.navigateByUrl('/recommendation');
    }, 2000);
  }

  loadGreeting(x) {
    this.message = Conversation.GREETING[x]
  }

  loadQuestion(newTheme) {
    this.message = ""
    if (newTheme) {
      this.message = Conversation.TRANSIT[this.theme]
    }
    let random = Math.floor(this.questionList.length * Math.random());
    this.qNumber = this.theme * 4 + this.questionList[random]
    this.message += "\n" + Conversation.QUESTIONS[this.qNumber].question
    this.questionList.splice(random, 1)
  }

  loadBye(x) {
    this.message = Conversation.BYE[x]
  }

}
