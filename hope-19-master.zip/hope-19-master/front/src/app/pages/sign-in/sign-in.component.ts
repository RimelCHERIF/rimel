import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MenuController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { User, user$ } from 'src/app/shared/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss'],
})
export class SignInComponent implements OnInit {

  signInForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private menuCtrl: MenuController, private http: HttpClient, private router: Router) { }

  ngOnInit() {
    this.signInForm = this.formBuilder.group({
      email: ['', Validators.compose([Validators.required, Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/)])],
      password: ['', Validators.required],
    })
  }

  signin() {
    if (this.signInForm.valid) {
      this.http.post('http://localhost:3000/users/login', this.signInForm.value)
        .toPromise()
        .then((res: User) => {
          localStorage.setItem('user', JSON.stringify(res));
          user$.next(res);
          this.router.navigate(['/chat']);
        });
    }
  }

}
