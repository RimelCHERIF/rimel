import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { MenuController } from '@ionic/angular';
import { User, user$ } from '../../shared/user'

interface SignUpForm {
  firstName: String;
  lastName: String;
  age: Number;
  password: String;
  rpassword: String;
  email: String
}

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss'],
})
export class SignUpComponent implements OnInit {

  form: SignUpForm;
  firstName: string = '';

  constructor(private http: HttpClient, private router: Router, private menuCtrl: MenuController) { }

  async ngOnInit() {
    this.form = {
      firstName: '',
      lastName: '',
      age: 0,
      email: '',
      password: '',
      rpassword: ''
    }
    await this.menuCtrl.enable(false);
  }

  createAccount() {
    console.log(this.form)
    this.http.post('http://localhost:3000/users', this.form)
      .toPromise()
      .then((res: User) => {
        localStorage.setItem('user', JSON.stringify(res));
        user$.next(res);
        setTimeout(() => {
          this.router.navigate(['/chat']);
        }, 1000);
      });
  }

  update(e, inputName) {
    if (inputName === 'age') {
      this.form.age = parseInt(e.target.value);
    }
    this.form[inputName] = e.target.value;
  }
}
