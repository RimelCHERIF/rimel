import { BehaviorSubject } from 'rxjs';

interface User {
  firstName: String;
  lastName: String;
  age: Number;
  email: String;
}

let user$: BehaviorSubject<User> = new BehaviorSubject<User>(null);

export { User, user$ };