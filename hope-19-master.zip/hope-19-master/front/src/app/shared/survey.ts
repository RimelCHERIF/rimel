export const Conversation = {
    GREETING: {
        0: "Hey Survivor 🖐 Glad to see you. Let me introduce myself. This is HOPE19 robot. My designers have been extremely worried about your well being (me too 😄). \
         I volunteered to assist you to anticipate any depression situation you may go through post Covid19.Would you mind to get to to know each other? yes, no"


    },
    TRANSIT: {
        0: "I am in a very good mood these days. What about you?",
        1: "I have never eaten your food. I am curious to know about it.",
        2: "You know my best quality is that I never get tired.",
        3: "Sorry ,  I know I am asking a lot but you look pretty zen. Is that correct?",
        4: "So proud of myself trying to help you. What about you?",
    },
    QUESTIONS: {
        0: {
            question: "How often do you feel down-hearted or blue?",
            asc: true
        },
        1: {
            question: "How often do you feel the best in the morning?",
            asc: false
        },
        2: {
            question: "How frequently do you have crying spells or feel like it?",
            asc: true
        },
        3: {
            question: "How frequently do you have trouble sleeping at night?",
            asc: true
        },
        4: {
            question: "Do you eat as much as you used to?",
            asc: false
        },
        5: {
            question: "At what rate do you still enjoy food?",
            asc: false
        },
        6: {
            question: "Do you notice that you are losing weight",
            asc: true
        },
        7: {
            question: "Do you have trouble with constipation?",
            asc: true
        },
        8: {
            question: "How frequently do your heart beats faster than usual?",
            asc: true
        },
        9: {
            question: "How frequently do you get tired for no reason?",
            asc: true
        },
        10: {
            question: "To what extent is your mind as clear as it used to be?",
            asc: false
        },
        11: {
            question: "To what extent do you find it easy to do the things you used to?",
            asc: false
        },
        12: {
            question: "How often do you feel restless and can’t keep still? ",
            asc: true
        },
        13: {
            question: "How often do you feel hopeful about the future?",
            asc: false
        },
        14: {
            question: "How frequently do you feel more irritable than usual?",
            asc: true
        },
        15: {
            question: "How often do you find it easy to make decisions?",
            asc: false
        },
        16: {
            question: "To what extent do you feel that you are useful and needed?",
            asc: false
        },
        17: {
            question: "How often do you feel that your life is pretty full?",
            asc: false
        },
        18: {
            question: "How often do you feel that others would be better off if you were dead?",
            asc: true
        },
        19: {
            question: "To what extent do you still enjoy the things you used to do?",
            asc: false
        }
    },
    RESULT: {

    },
    BYE: {
        0: "Thank you 😄, I really enjoyed talking to you. In few seconds, I will redirect you to some recommendations that might help you. \n Bye Bye 🖐",
        1: "May be an other time. Meanwhile, take care of yourself 😉."

    },
    UNUNDERSTOOD: {
        0: "Sorry, I didn't understant!"
    },
    REFUSE: ["No", "No please!", "I dont' want to"],
    ACCEPT: ["Let's start!", "Yes", "OK", "Please"]


}