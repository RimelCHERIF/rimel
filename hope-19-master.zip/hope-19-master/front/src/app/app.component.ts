import { Component, OnInit } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Observable } from 'rxjs';
import { User, user$ } from './shared/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  public selectedIndex = 0;
  public appPages = [
    {
      title: 'Chat',
      url: '/chat',
      icon: 'paper-plane'
    },
    // {
    //   title: 'Our Recommendations',
    //   url: '/recommendation',
    //   icon: 'leaf'
    // },
  ];

  public user: User;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private router: Router
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  ngOnInit() {
    user$.subscribe((val) => {
      if (val === null) {
        this.user = JSON.parse(localStorage.getItem('user')) || {
          firstName: '',
          lastName: '',
          age: 0,
          email: '',
        }
      } else {
        this.user = val;
      }
    })
  }

  logout() {
    //user$.next(null);
    localStorage.removeItem('user');
    this.router.navigate(['/home']);
  }
}
