export class Recommendation {
    name: string;
    type: string;
    url: string;
    imagePath: string;
}